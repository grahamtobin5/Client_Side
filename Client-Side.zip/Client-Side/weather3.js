var el = document.getElementById('weatherRefresh');
el.onclick = getData;
