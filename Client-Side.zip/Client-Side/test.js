function updateConditions(data) {

} 
